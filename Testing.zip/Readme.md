# Desarollo remoto de Pangea

Esta rama, continene todos los archivos necesarios para realizar un desarollo en remoto de el proyecto de Pangea

## Requisitos

De momento, hace falta tener instalado VSCode, mas tarde creare un entorno de desarollo independiente de este IDE

- [VSCode](https://code.visualstudio.com/)
- Extensión: [VSCode Remote Tools](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.vscode-remote-extensionpack) (Te aparecera un cuadro abajo a la derecha si abres VSCode en esta carpeta)

## Ventajas de usar este entorno de desarollo con VSCode

- Linter conectado con VSCode, estandar utilizado PEP8
- VSCode, con varias extensiones auto-instaladas para el entorno de DJango

## Pasos para iniciar el desarollo

1. Descargar esta rama de desarollo
2. Ejecutar el comando `docker-compose build`
3. Ejecutar el comando `docker-compose up`

Una vez ejecutado los comandos anteriores, abrir el menu de "Explorador Remoto"

![DEMO](./RemoteENVS.png)

Al ser 2 contenedores independientes, hace falta tener 2 editores abiertos

En el que estamos ahora, abrimos el contenedor de Orchestra, haciendo click en la carpeta

Para abirir el contenedor de Musician, abrimos una nueva ventana de VSCode, abrimos el "Explorador Remoto" y hacemos click en la carpeta de musician

> Aqui ya esta todo listo, ya puedes desarollar a gusto