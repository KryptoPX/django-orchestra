. ~/env/bin/activate
cd panel
python manage.py runserver 9999