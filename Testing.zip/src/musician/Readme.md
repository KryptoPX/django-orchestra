# Bienvenido al contenedor de Orchestra-admin

este contenedor el repositorio actualizado de django-orchestra.

## Features activadas

- Linter conectado con VSCode, estandar utilizado PEP8
- VSCode, con varias extensiones auto-instaladas para el entorno de DJango

## Comando para iniciar el servidor

```
./runServer.sh
```

