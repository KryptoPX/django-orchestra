. ~/env/bin/activate
cd django-musician 
python manage.py runserver 8080